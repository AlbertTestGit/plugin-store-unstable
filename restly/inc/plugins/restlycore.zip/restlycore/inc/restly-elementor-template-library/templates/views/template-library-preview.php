<script type="text/template" id="rave-TemplateLibrary_preview">
    <img class="liteTemplateLibrary_template-preview-thumbnail">
</script>

<script type="text/template" id="rave-TemplateLibrary_header-insert">
	<div id="elementor-template-library-header-preview-insert-wrapper" class="elementor-templates-modal__header__item">
		{{{ rave.library.getModal().getTemplateActionButton( obj ) }}}
	</div>
</script>